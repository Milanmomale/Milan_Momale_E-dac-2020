package ls;

import java.util.Scanner;

class Student
{
    int rollNo;
    double marks;
    String name;
    
    Student (){}
    Student(int r,double mks,String n)
    {
        rollNo=r;
        marks=mks;
        name=n;
    }
    void display()
    {
        System.out.println("Name is :"+name);
        System.out.println("Roll no is :"+rollNo);
        System.out.println("marks are :"+marks);
    }
}

class StudentDetails
{
    public static void main(String[] args) {
        
        int r;
        double mks;
        String n;
        Student s1=new Student(11,0,"Nobita");
        Student s2=new Student (12,450,"Shizuka");
        System.out.println("Details of first Student :");
        s1.display();
        System.out.println("Details of second Student :");
        s2.display();
    }
}