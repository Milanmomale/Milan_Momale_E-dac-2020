package ls;

import java.util.Scanner;

class Book
{
    int id;
    String name;
    double price;
            Book(){}
            Book(int i,String n,double p)
            {
               id =i;
               name =n;
               price=p;
                
            }
          void display()
          {
              System.out.println("The id of the book is"+id);
              System.out.println("Name of the book is :"+name);
              System.out.println("Price of the book is :"+price);
          }  
            
    
}
class BookPrice
{
    public static void main(String[] args) {
        double max=0;
        int key =0;
        Book b1[]=new Book[5];
        int i;
        String n;
        double p;
        Scanner sc=new Scanner(System.in);
        for (int m=0;m<5;m++)
        {
            
            i=sc.nextInt();
            n=sc.nextLine();
            sc.nextLine();
            p=sc.nextDouble();
            b1[m]= new Book(i,n,p);
        }
        for (int m=0;m<5;m++)
        {
            if(b1[m].price>max)
            {
                key=m;
                max=b1[m].price;
            }
        }
        System.out.println("The highest price of a book is :"+max);
        b1[key].display();
    }
}