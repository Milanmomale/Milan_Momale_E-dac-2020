/*WAP to define a class Employee with attributes id, name ,designation 
Accept data for 5 objects and display employee details whose designation is Manager*/
package ls;
import java.util.Scanner;

class Manager
{
    int id;
    String name;
    String designation;
                    Manager(){}
                    Manager(int no,String nm,String pos)
                    {
                        id=no;
                        name=nm;
                        designation=pos;
                    }
            void display()
            {
                System.out.println("ID of the Employee:"+id);
                System.out.println("Name of the Employee:"+name);
                System.out.println("Designation of the Employee:"+designation);
            }        

}
class Employee
{
    public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      int no;
      String nm;
      String pos;
      Manager m1[]=new Manager[5];
      for (int i=0;i<5;i++)
      {
          no=sc.nextInt();
          nm=sc.nextLine();
          sc.nextLine();
          pos=sc.nextLine();
          m1[i]= new Manager(no,nm,pos);
      }
      String mn="Manager";
      for (int i=0;i<5;i++)
      {
          System.out.println("Employee with designation as managers are below");
          if(m1[i].designation.equals(mn))
          {
              m1[i].display();
          }
      }
       
    }
}