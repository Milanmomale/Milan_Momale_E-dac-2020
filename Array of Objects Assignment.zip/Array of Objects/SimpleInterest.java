/*WAP to define Class Simpleinterest with attributes principalamount,  rate of interest static ,number of years calculate SI and display it. */
package ls;
import java.util.Scanner;

class Interest
{
    static float rateOfInterest=8;
    float principalAmount;
    float numberOfYears;
    float simpleInterest;
            Interest(){}
            Interest(float p,float t)
            {
                principalAmount=p;
                numberOfYears=t;
            }
            
            float display()
            {
                simpleInterest=(principalAmount*rateOfInterest*numberOfYears)/100;
               System.out.println("Simple Interest is :"+simpleInterest);
               return simpleInterest;
            }
}


class SimpleInterest
{
    public static void main(String args[])
    {
        float p,t;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Principal Amount:");
        p=sc.nextFloat();
        System.out.println("Enter the Number of years:");
        t=sc.nextFloat();
        Interest I1=new Interest(p,t);
        I1.display();
    }
}