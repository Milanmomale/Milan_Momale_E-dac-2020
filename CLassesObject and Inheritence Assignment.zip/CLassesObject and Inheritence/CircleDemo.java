package VP;

import java.util.Scanner;

class Circle
{   double radious;
    double area;
     void init()
     {
         Scanner sc=new Scanner(System.in);
        radious=sc.nextDouble();
     }
     
     
     double area()
     {
         double pi=3.14;
         area=pi*radious*radious;
         return area;
     }
     
     void display()
     {
         System.out.println(radious);
         System.out.println(area);
     }

}

 class CicleDemo
 {
        public static void main(String[] args) {
        Circle s1=new Circle();
        s1.init();
        s1.area();
        s1.display();
 }
}