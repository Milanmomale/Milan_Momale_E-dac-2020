package VP;

import java.util.Scanner;

/*Create a class MathOperation that has four static methods. add() method that
takes two integer numbers as parameter and returns the sum of the numbers.
subtract() method that takes two integer numbers as parameter and returns
the difference of the numbers. multiply() method that takes two integer
numbers as parameter and returns the product. power() method that takes
two integer numbers as parameter and returns the power of first number to
second number. Create another class Demo (main class) that takes the two
numbers from the user and calls all four methods of MathOperation class by
providing entered numbers and prints the return values of every method*/
class MathOperation
{   
     static int add(int a, int b)
     {
        int c=a+b;
        return c;
     }
     
     static int sub(int a, int b)
     {
        int c=a-b;
        return c;
     }
     static int mul(int a, int b)
     {
        int c=a*b;
        return c;
     }
     static double div(double a,double  b)
     {
       double c=a/b;
        return c;
     }
     static double power(int a, int b)
     {
        double c=Math.pow(a, b);
        return c;
     }

}

 class Demo
 {
        public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            int a=sc.nextInt();
            int b=sc.nextInt();
            System.out.println(MathOperation.add(a, b));
            System.out.println(MathOperation.sub(a, b));
            System.out.println(MathOperation.mul(a, b));
            System.out.println(MathOperation.div(a, b));
            System.out.println(MathOperation.power(2, 2));
 }
}