package VP;
import java.util.Scanner;
/*1. Create class Product with three data members (pid, price, quantity) and
parameterized constructor that takes values for all three data members.
Create a main method in different class (say ProductDemo) and perform
following task:
a. Accept information for five Product objects from user and store objects in
an array
b. Find pid of product with highest price.
c. Create a static method (with array of product’s object as argument) in
Product class to calculate and return total amount spent on all products. (
amount spent on single product = price of product * quantity of product )*/
class Product
{
    int pid;
    double price;
    int quantity;
    
    Product(int pid,double price,int quantity)
    {
        this.pid=pid;
        this.price=price;
        this.quantity=quantity;        
    }
    
    public static double calculate(Product p[])
    {
       double totalAmount=0;
       for(int i=0;i<p.length;i++){
       totalAmount=totalAmount+ (p[i].price*p[i].quantity) ;
               }
       return totalAmount;
    }
            
    
    
}

class ProductDemo
{
    public static void main(String[] args) {
        
    
                Product p[]=new Product[5];
                Scanner sc=new Scanner(System.in);
                for (int i=0;i<5;i++)
                    {
                        int pid=sc.nextInt();
                        double price=sc.nextDouble();
                        int quantity=sc.nextInt();
                        p[i]=new Product(pid,price,quantity);
                    }
                double max=0;
                int pidHighest=0;
                for (int m=0;m<p.length;m++)
                {
                    if(p[m].price>max){
                        max=p[m].price;
                       pidHighest=p[m].pid;
                    }
                }
                System.out.println("The Pid of the Product With Highest Price "+max+" is "+pidHighest);
                
                System.out.println("The total amount spent on all products is :"+Product.calculate(p));
    }
}