package VP;

class MathOp
{
    int multiply(int a ,int b)
    {
        int c=a*b;
        return c;     
    }
    float multiply(float a ,float b,float c)
    {
        float d=a*b*c;
        return d;     
    }
    int multiply(int arr[])
    {
        int p=1;
        for (int i = 0; i <5; i++)
        {
        p=p*arr[i];    
        }
        return p;     
    }
    double multiply(double a ,int b)
    {
        double c=(int) (a*b);
        return c;     
    }
    public static void main(String[] args) {
       MathOp m1=new MathOp();
       int arr[]={1,2,3,4,5};
        System.out.println(m1.multiply(10,20));
        System.out.println(m1.multiply(10.0f,20.0f,30.5f));
        System.out.println(m1.multiply(arr));
        System.out.println(m1.multiply(12.56,20));
    }

    }